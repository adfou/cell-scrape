from django.contrib import admin
from .models import Article,Head,word,Madjmo3at,fichie

admin.site.register(Article)
admin.site.register(Head)
admin.site.register(Madjmo3at)
admin.site.register(fichie)
admin.site.register(word)
# Register your models here.
    