from models import Madjmo3at
# Create your tests here.
Madjmo3at = Madjmo3at()
article.text = 'النش'
Madjmo3at.save()